#include <jni.h>
#include <string>
using std::string;

extern "C" JNIEXPORT jstring

JNICALL Java_com_example_eppsna01_tictactoe2_MainActivity_stringFromJNI(JNIEnv* env, jobject self)
{
    string hello = "Hello, World!";

    return env->NewStringUTF(hello.c_str());
}
